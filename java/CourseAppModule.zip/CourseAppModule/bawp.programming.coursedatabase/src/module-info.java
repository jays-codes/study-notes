module bawp.programming.coursedatabase {
    exports bawp.programming.coursedatabase;

}