module bawp.programming.courseapp {
    requires bawp.programming.coursedatabase;
    requires jdk.incubator.httpclient;


}